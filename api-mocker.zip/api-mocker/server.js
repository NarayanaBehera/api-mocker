const express = require("express");
const bodyParser = require("body-parser");
const fs = require("fs");
const path = require("path");

const app = express();
app.use(bodyParser.json());

// Load config.json
const config = JSON.parse(fs.readFileSync("config.json", "utf-8"));
const PORT = config.port || 9438;

// Register routes dynamically
config.routes.forEach((route) => {
  const method = route.method.toLowerCase();

  app[method](route.path, (req, res) => {
    console.log(`➡️ Mock Request: ${route.method} ${req.originalUrl}`);

    let responseBody;

    if (route.response.file) {
      // Load JSON response from external file
      const filePath = path.join(__dirname, route.response.file);
      responseBody = JSON.parse(fs.readFileSync(filePath, "utf-8"));
    } else {
      // Fallback: use inline body from config.json
      responseBody = route.response.body || {};
    }

    res.status(route.response.status).json(responseBody);
  });
});

// Start server
app.listen(PORT, () => {
  console.log(`🚀 API Mocker running at http://localhost:${PORT}`);
});
