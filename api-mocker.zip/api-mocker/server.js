const express = require('express');
const fs = require('fs');
const path = require('path');
const jsonpath = require('jsonpath'); // npm install jsonpath
const app = express();

// Load config
const config = require('./config.json');

// Middleware to parse JSON body
app.use(express.json());

config.routes.forEach(route => {
  const method = route.method.toLowerCase();

  app[method](route.path, (req, res) => {
    try {
      let filePath;
      let status;

      // Case 1: Simple static response
      if (route.response) {
        filePath = path.join(__dirname, route.response.file);
        status = route.response.status;
      }

      // Case 2: Routes with switches
      else if (route.switch && route.responses && route.switchResponses) {
        let switchKey = '';

        // Generate the switchKey by concatenating all switch values
        for (const sw of route.switch) {
          let value = '';

          if (typeof sw === 'string') {
            // URL param
            value = req.params[sw] || '';
          } else if (sw.type === 'jsonpath') {
            // JSONPath from body
            const result = jsonpath.query(req.body, sw.switch);
            value = result[0] !== undefined ? String(result[0]) : '';
          }

          switchKey += value;
        }

        console.log('[Mock] Generated switchKey:', switchKey);

        // Check if there is a matching switch response
        if (route.switchResponses[switchKey]) {
          const resp = route.switchResponses[switchKey];
          filePath = path.join(__dirname, resp.mockFile);
          status = resp.httpStatus;
        } else {
          // Fallback default response
          const resp = route.responses[method] || route.responses[route.method];
          if (resp) {
            filePath = path.join(__dirname, resp.mockFile);
            status = resp.httpStatus;
          } else {
            return res.status(404).json({ error: 'No matching mock config' });
          }
        }
      }

      // If filePath is still undefined
      if (!filePath) {
        return res.status(404).json({ error: 'No mock file configured' });
      }

      // Check if file exists
      if (!fs.existsSync(filePath)) {
        console.error('[Mock] File not found:', filePath);
        return res.status(500).json({ error: 'Mock file not found' });
      }

      const fileContent = fs.readFileSync(filePath, 'utf8');
      res.status(status).json(JSON.parse(fileContent));

    } catch (err) {
      console.error('[Mock] Error:', err.message);
      res.status(500).json({ error: 'Mock server internal error' });
    }
  });
});

const port = config.port || 3000;
app.listen(port, () => {
  console.log(`Mock server running on port ${port}`);
});
